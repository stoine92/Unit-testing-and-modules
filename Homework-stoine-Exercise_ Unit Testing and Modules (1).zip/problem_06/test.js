let assert = require('chai').assert;
let PaymentPackage = require('./PaymentPackage');
 
describe('PaymentPackage', function() {
 
    describe('Ctor', function() {
        it('should vreate new Payment package', function() {
            let paymentPackage = new PaymentPackage('Mine', 1300);
 
            assert.equal('Mine', paymentPackage.name);
            assert.equal(1300, paymentPackage.value);
        });
 
        it('error while trying to set an empty string', () => {
            assert.throw(() => {
                new PaymentPackage('', 584);
            }, 'Name must be a non-empty string');
        });
 
        it('should thrhow error while trying with a non string name', function() {
            assert.throw(() => {
                new PaymentPackage(1000, 1000)
            }, 'Name must be a non-empty string');
        });
 
        it('should throw error while trying to set a negative number as prop', function() {
            assert.throw(() => {
                new PaymentPackage('Pesho', -584);
            }, 'Value must be a non-negative number');
        });
 
        it('should throw error while trying to set not a number as prop', function() {
            assert.throw(() => {
                new PaymentPackage('Pesho', 'bla');
            }, 'Value must be a non-negative number');
        })
 
        it('should throw an error while trying to set a negative number to VAT', function() {
            assert.throw(() => {
                let package = new PaymentPackage('Pesho', 1155);
                package.VAT = 'string';
            }, 'VAT must be a non-negative number');
        });
 
        it('should throw an error while trying to set a non boloena value to active', function() {
            assert.throw(() => {
                let package = new PaymentPackage('Pesho', 1155);
                package.active = 'string';
            }, 'Active status must be a boolean');
        });
 
        it('toString should return string with overview of an instance when ACTIVE', () => {
            let package = new PaymentPackage('Pesho', 55);
            const result = [
                `Package: Pesho`,
                `- Value (excl. VAT): 55`,
                `- Value (VAT ${20}%): ${66}`,
            ];
            assert.equal(result.join('\n'), package.toString());
        });
 
        it('toString should return string with overview of an instance when NOT ACTIVE', () => {
            let package = new PaymentPackage('Pesho', 55);
            package.active = false;
            const result = [
                `Package: Pesho (inactive)`,
                `- Value (excl. VAT): 55`,
                `- Value (VAT ${20}%): ${66}`,
            ];
            assert.equal(result.join('\n'), package.toString());
        });
    });
 
})