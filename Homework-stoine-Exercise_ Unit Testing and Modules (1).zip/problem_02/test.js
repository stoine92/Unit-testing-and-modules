let assert = require('chai').assert;
let app = require('./isOddOrEven.js');

describe('isItEvenOrOdd', () =>{
    it('should return undefined different from string ', () =>{
        assert.equal(undefined, app.isOddOrEven(7));
    })
    it('should return even', () =>{
        assert.equal('even', app.isOddOrEven('defo'));
    })
    it('should return odd', () =>{
        assert.equal('odd', app.isOddOrEven('notdefo'));
    })
})