let {assert} = require('chai');
let StringBuilder = require('./stringBuilder.js');

describe('stringBuilder', () => {
    let sb;
    beforeEach(() =>{
        sb = new StringBuilder();
    });

    describe('verifyParams', () => {
        it('should throw exceptions when param is not a string', () => {
            assert.throw(() =>{
                new StringBuilder({});

            }, 'Argument must be string');

        })
    })

    describe('constructor', () =>{
        it('should work right without any arguments', () => {
            assert.equal("", sb.toString())
        })
        it('should work right with an arguments', () => {
            sb = new StringBuilder('pesho');

            assert.equal("pesho", sb.toString())
        })
    })
    describe('append', () => {
        it('should work right', () =>{  
            sb.append('pesho');
            assert.equal('pesho', sb.toString());
        });
    })
    describe('prepend', () => {
        it('should add a word to the start of the string', () =>{  
            sb.prepend('pesho');
            assert.equal('pesho', sb.toString());
        });
    })
    describe('insertAt', () => {
        it('should insert on a given index', () =>{  
            sb.append('psho');
            sb.insertAt('e', 1)
            assert.equal('pesho', sb.toString());
        });
    })
    describe('remove', () => {
        it('should slice a given text', () =>{  
            sb.append('pesho');
            sb.remove(0, 1)
            assert.equal('esho', sb.toString());
        });
    })
    describe('toString', () => {
        it('should return correct string', () =>{  
            sb.append('pesho');
            assert.equal('pesho', sb.toString());
        });
    })
})