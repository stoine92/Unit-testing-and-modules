let {assert} = require('chai');
let {lookUpChar} = require('./charLookUp.js');

describe('charLookUp', () => {
    it('should return undefined with first one', () => {
        assert.equal(undefined, lookUpChar(5, 0));
    })
    it('should return undefined with second one', () => {
        assert.equal(undefined, lookUpChar('pesho', 'gosho'));
    })
    it('should return incorrect index with first one', () => {
        assert.equal('incorrect index', lookUpChar('pesho', 5));
    })
    it('should return incorrect index with second one', () => {
        assert.equal('incorrect index', lookUpChar('gosho', -1));
    })
    it('should return correct', () => {
        assert.equal('a', lookUpChar('Styan', 3));
    })
})