let {addFive, subtractTen, sum} = require('./mathEnforcer.js');
let {assert} = require('chai');

describe('mathEnforcer', () =>{
    describe('addFive', () => {
        it('should return undefined with incorrect type', () => {
            assert.equal(undefined, addFive('Stamat'));
        })
        it('should return correct number', () => {
            assert.equal(10, addFive(5));
        })

    })
    describe('subtractTen', () => {
        it('should return undefined with incorrect type', () => {
            assert.equal(undefined, subtractTen('Stamat'));
        })
        it('should return correct value', () => {
            assert.equal(0, subtractTen(0));
        })
    })
    describe('sum', () => {
        it('should return undefined with incorrect first one', () =>{
            assert.equal(undefined, sum('Stamat', 5))
        })
        it('should return undefined with incorrect second one', () =>{
            assert.equal(undefined, sum(5, 'Stamat'))
        })
        it('should return correct sum', () =>{
            assert.equal(10, sum(5, 5));
        })
    })

})